package com.ofte.list.services;

public class TransferDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
