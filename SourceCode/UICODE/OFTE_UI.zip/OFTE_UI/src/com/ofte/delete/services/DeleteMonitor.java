package com.ofte.delete.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DeleteMonitor {
	public static void main(String[] args) {
		String taskName = args[0];
		List<String> commands = new ArrayList<String>();
		commands.add("schtasks.exe");
		commands.add("/delete");
		commands.add("/tn");
		commands.add(taskName);
		commands.add("/f");
		// commands.add("schtasks.exe");
		// commands.add("/DELETE");
		// commands.add("/S");
		// commands.add("\"ws-abacus\"");
		// commands.add("/TN");
		// commands.add("\"test709\"");
		// commands.add(taskName);
		// commands.add(" /F");
		// commands.add("schtasks " + "/delete " + "/tn " + "test709" + " /f");
		// System.out.println(commands);
		ProcessBuilder builder = new ProcessBuilder(commands);
		Process processTask = null;
		try {
			processTask = builder.start();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			processTask.waitFor();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(processTask.exitValue());
		System.out.println("done");

	}

}
